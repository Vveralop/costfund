import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { AlmLoandepo } from "./AlmLoandepo";
import { AlmLoandepoSimulation } from "./AlmLoandepoSimulation";
import { AccountTypes } from "./AccountTypes";
import { Calendars } from "./Calendars";
import { Conventions } from "./Conventions";
import { Currencies } from "./Currencies";
import { DateGenerationRules } from "./DateGenerationRules";
import { CurveDescriptions } from "./CurveDescriptions";
import { Compoundings } from "./Compoundings";
import { DayCounters } from "./DayCounters";
import { Frequencies } from "./Frequencies";
import { ProductFamilies } from "./ProductFamilies";
import { RateTypes } from "./RateTypes";
import { Segments } from "./Segments";
import { Sides } from "./Sides";
import { Structures } from "./Structures";
import { LoandepoQuotes } from "./LoandepoQuotes";

@Index("loandepo_configurations_pkey", ["id"], { unique: true })
@Entity("loandepo_configurations", { schema: "ingfin" })
export class LoandepoConfigurations {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "name", length: 100 })
  name: string;

  @Column("character varying", {
    name: "description",
    nullable: true,
    length: 255,
  })
  description: string | null;

  @Column("integer", { name: "validation_id", nullable: true })
  validationId: number | null;

  @Column("boolean", { name: "is_active" })
  isActive: boolean;

  @Column("boolean", { name: "end_of_month" })
  endOfMonth: boolean;

  @OneToMany(
    () => AlmLoandepo,
    (almLoandepo) => almLoandepo.loandepoConfiguration
  )
  almLoandepos: AlmLoandepo[];

  @OneToMany(
    () => AlmLoandepoSimulation,
    (almLoandepoSimulation) => almLoandepoSimulation.loandepoConfiguration
  )
  almLoandepoSimulations: AlmLoandepoSimulation[];

  @ManyToOne(
    () => AccountTypes,
    (accountTypes) => accountTypes.loandepoConfigurations
  )
  @JoinColumn([{ name: "account_type_id", referencedColumnName: "id" }])
  accountType: AccountTypes;

  @ManyToOne(() => Calendars, (calendars) => calendars.loandepoConfigurations)
  @JoinColumn([{ name: "calendar_id", referencedColumnName: "id" }])
  calendar: Calendars;

  @ManyToOne(
    () => Conventions,
    (conventions) => conventions.loandepoConfigurations
  )
  @JoinColumn([{ name: "convention_id", referencedColumnName: "id" }])
  convention: Conventions;

  @ManyToOne(
    () => Currencies,
    (currencies) => currencies.loandepoConfigurations
  )
  @JoinColumn([{ name: "currency_id", referencedColumnName: "id" }])
  currency: Currencies;

  @ManyToOne(
    () => DateGenerationRules,
    (dateGenerationRules) => dateGenerationRules.loandepoConfigurations
  )
  @JoinColumn([{ name: "date_generation_rule_id", referencedColumnName: "id" }])
  dateGenerationRule: DateGenerationRules;

  @ManyToOne(
    () => CurveDescriptions,
    (curveDescriptions) => curveDescriptions.loandepoConfigurations
  )
  @JoinColumn([{ name: "discount_curve_id", referencedColumnName: "id" }])
  discountCurve: CurveDescriptions;

  @ManyToOne(
    () => Compoundings,
    (compoundings) => compoundings.loandepoConfigurations
  )
  @JoinColumn([
    { name: "first_rate_compounding_id", referencedColumnName: "id" },
  ])
  firstRateCompounding: Compoundings;

  @ManyToOne(
    () => DayCounters,
    (dayCounters) => dayCounters.loandepoConfigurations
  )
  @JoinColumn([
    { name: "first_rate_day_counter_id", referencedColumnName: "id" },
  ])
  firstRateDayCounter: DayCounters;

  @ManyToOne(
    () => Frequencies,
    (frequencies) => frequencies.loandepoConfigurations
  )
  @JoinColumn([{ name: "first_rate_frequency_id", referencedColumnName: "id" }])
  firstRateFrequency: Frequencies;

  @ManyToOne(
    () => CurveDescriptions,
    (curveDescriptions) => curveDescriptions.loandepoConfigurations2
  )
  @JoinColumn([{ name: "forecast_curve_id", referencedColumnName: "id" }])
  forecastCurve: CurveDescriptions;

  @ManyToOne(
    () => Frequencies,
    (frequencies) => frequencies.loandepoConfigurations2
  )
  @JoinColumn([{ name: "payment_frequency_id", referencedColumnName: "id" }])
  paymentFrequency: Frequencies;

  @ManyToOne(
    () => ProductFamilies,
    (productFamilies) => productFamilies.loandepoConfigurations
  )
  @JoinColumn([{ name: "product_family_id", referencedColumnName: "id" }])
  productFamily: ProductFamilies;

  @ManyToOne(() => RateTypes, (rateTypes) => rateTypes.loandepoConfigurations)
  @JoinColumn([{ name: "rate_type_id", referencedColumnName: "id" }])
  rateType: RateTypes;

  @ManyToOne(
    () => Compoundings,
    (compoundings) => compoundings.loandepoConfigurations2
  )
  @JoinColumn([
    { name: "second_rate_compounding_id", referencedColumnName: "id" },
  ])
  secondRateCompounding: Compoundings;

  @ManyToOne(
    () => DayCounters,
    (dayCounters) => dayCounters.loandepoConfigurations2
  )
  @JoinColumn([
    { name: "second_rate_day_counter_id", referencedColumnName: "id" },
  ])
  secondRateDayCounter: DayCounters;

  @ManyToOne(
    () => Frequencies,
    (frequencies) => frequencies.loandepoConfigurations3
  )
  @JoinColumn([
    { name: "second_rate_frequency_id", referencedColumnName: "id" },
  ])
  secondRateFrequency: Frequencies;

  @ManyToOne(() => Segments, (segments) => segments.loandepoConfigurations)
  @JoinColumn([{ name: "segment_id", referencedColumnName: "id" }])
  segment: Segments;

  @ManyToOne(() => Sides, (sides) => sides.loandepoConfigurations)
  @JoinColumn([{ name: "side_id", referencedColumnName: "id" }])
  side: Sides;

  @ManyToOne(
    () => Structures,
    (structures) => structures.loandepoConfigurations
  )
  @JoinColumn([{ name: "structure_id", referencedColumnName: "id" }])
  structure: Structures;

  @OneToMany(
    () => LoandepoQuotes,
    (loandepoQuotes) => loandepoQuotes.loandepoConfiguration
  )
  loandepoQuotes: LoandepoQuotes[];
}
