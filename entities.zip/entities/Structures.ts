import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { LoandepoConfigurations } from "./LoandepoConfigurations";

@Index("structures_pkey", ["id"], { unique: true })
@Index("structures_structure_key", ["structure"], { unique: true })
@Entity("structures", { schema: "ingfin" })
export class Structures {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "structure", unique: true, length: 50 })
  structure: string;

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.structure
  )
  loandepoConfigurations: LoandepoConfigurations[];
}
