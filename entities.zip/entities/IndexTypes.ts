import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { InterestRateIndexes } from "./InterestRateIndexes";

@Index("index_types_pkey", ["id"], { unique: true })
@Index("index_types_index_type_key", ["indexType"], { unique: true })
@Entity("index_types", { schema: "ingfin" })
export class IndexTypes {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "index_type", unique: true, length: 50 })
  indexType: string;

  @OneToMany(
    () => InterestRateIndexes,
    (interestRateIndexes) => interestRateIndexes.indexType
  )
  interestRateIndexes: InterestRateIndexes[];
}
