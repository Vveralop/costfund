import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { LoanQuoteCashflows } from "./LoanQuoteCashflows";
import { LoandepoConfigurations } from "./LoandepoConfigurations";
import { QuoteStatuses } from "./QuoteStatuses";

@Index("loandepo_quotes_pkey", ["id"], { unique: true })
@Entity("loandepo_quotes", { schema: "ingfin" })
export class LoandepoQuotes {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("date", { name: "reference_date" })
  referenceDate: string;

  @Column("character varying", { name: "start_period", length: 50 })
  startPeriod: string;

  @Column("character varying", { name: "end_period", length: 50 })
  endPeriod: string;

  @Column("double precision", { name: "notional", precision: 53 })
  notional: number;

  @Column("double precision", { name: "first_rate", precision: 53 })
  firstRate: number;

  @Column("double precision", { name: "second_rate", precision: 53 })
  secondRate: number;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @OneToMany(
    () => LoanQuoteCashflows,
    (loanQuoteCashflows) => loanQuoteCashflows.loandepoQuote
  )
  loanQuoteCashflows: LoanQuoteCashflows[];

  @ManyToOne(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.loandepoQuotes
  )
  @JoinColumn([
    { name: "loandepo_configuration_id", referencedColumnName: "id" },
  ])
  loandepoConfiguration: LoandepoConfigurations;

  @ManyToOne(
    () => QuoteStatuses,
    (quoteStatuses) => quoteStatuses.loandepoQuotes
  )
  @JoinColumn([{ name: "quote_status_id", referencedColumnName: "id" }])
  quoteStatus: QuoteStatuses;
}
