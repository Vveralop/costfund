import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Index("alm_tmp_fixings_pkey", ["id"], { unique: true })
@Entity("alm_tmp_fixings", { schema: "ingfin" })
export class AlmTmpFixings {
  @PrimaryGeneratedColumn({ type: "bigint", name: "id" })
  id: string;

  @Column("character varying", { name: "ticker", length: 50 })
  ticker: string;

  @Column("double precision", { name: "value", precision: 53 })
  value: number;

  @Column("date", { name: "reference_date" })
  referenceDate: string;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;
}
