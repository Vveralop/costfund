import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Index("alm_npv_simulation_pkey", ["id"], { unique: true })
@Entity("alm_npv_simulation", { schema: "ingfin" })
export class AlmNpvSimulation {
  @PrimaryGeneratedColumn({ type: "bigint", name: "id" })
  id: string;

  @Column("character varying", { name: "name", length: 255 })
  name: string;

  @Column("character varying", { name: "description", length: 255 })
  description: string;

  @Column("date", { name: "portfolio_date" })
  portfolioDate: string;

  @Column("date", { name: "market_data_date" })
  marketDataDate: string;

  @Column("character varying", { name: "user", length: 50 })
  user: string;

  @Column("character varying", { name: "horizon", length: 50 })
  horizon: string;

  @Column("character varying", { name: "status", length: 50 })
  status: string;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;
}
