import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { LoandepoConfigurations } from "./LoandepoConfigurations";
import { AlmRolloverSimulation } from "./AlmRolloverSimulation";

@Index("alm_loandepo_simulation_pkey", ["id"], { unique: true })
@Entity("alm_loandepo_simulation", { schema: "ingfin" })
export class AlmLoandepoSimulation {
  @PrimaryGeneratedColumn({ type: "bigint", name: "id" })
  id: string;

  @Column("double precision", {
    name: "notional",
    nullable: true,
    precision: 53,
  })
  notional: number | null;

  @Column("date", { name: "start_date", nullable: true })
  startDate: string | null;

  @Column("date", { name: "end_date", nullable: true })
  endDate: string | null;

  @Column("double precision", { name: "rate", nullable: true, precision: 53 })
  rate: number | null;

  @ManyToOne(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.almLoandepoSimulations
  )
  @JoinColumn([
    { name: "loandepo_configuration_id", referencedColumnName: "id" },
  ])
  loandepoConfiguration: LoandepoConfigurations;

  @ManyToOne(
    () => AlmRolloverSimulation,
    (almRolloverSimulation) => almRolloverSimulation.almLoandepoSimulations
  )
  @JoinColumn([{ name: "simulation_id", referencedColumnName: "id" }])
  simulation: AlmRolloverSimulation;
}
