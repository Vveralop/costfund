import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Index("bbg_derivatives_pkey", ["id"], { unique: true })
@Entity("bbg_derivatives", { schema: "ingfin" })
export class BbgDerivatives {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "ticker", length: 50 })
  ticker: string;

  @Column("double precision", { name: "value", precision: 53 })
  value: number;

  @Column("date", { name: "maturity_date", nullable: true })
  maturityDate: string | null;

  @Column("date", { name: "reference_date" })
  referenceDate: string;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;
}
