import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { BondRateHelpers } from "./BondRateHelpers";
import { DepositRateHelpers } from "./DepositRateHelpers";
import { FxswapRateHelpers } from "./FxswapRateHelpers";
import { InterestRateIndexes } from "./InterestRateIndexes";
import { LoandepoConfigurations } from "./LoandepoConfigurations";
import { OisRateHelpers } from "./OisRateHelpers";
import { SwapRateHelpers } from "./SwapRateHelpers";
import { XccyRateHelpers } from "./XccyRateHelpers";

@Index("conventions_convention_key", ["convention"], { unique: true })
@Index("conventions_pkey", ["id"], { unique: true })
@Entity("conventions", { schema: "ingfin" })
export class Conventions {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "convention", unique: true, length: 50 })
  convention: string;

  @OneToMany(
    () => BondRateHelpers,
    (bondRateHelpers) => bondRateHelpers.convention
  )
  bondRateHelpers: BondRateHelpers[];

  @OneToMany(
    () => DepositRateHelpers,
    (depositRateHelpers) => depositRateHelpers.convention
  )
  depositRateHelpers: DepositRateHelpers[];

  @OneToMany(
    () => FxswapRateHelpers,
    (fxswapRateHelpers) => fxswapRateHelpers.convention
  )
  fxswapRateHelpers: FxswapRateHelpers[];

  @OneToMany(
    () => InterestRateIndexes,
    (interestRateIndexes) => interestRateIndexes.convention
  )
  interestRateIndexes: InterestRateIndexes[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.convention
  )
  loandepoConfigurations: LoandepoConfigurations[];

  @OneToMany(
    () => OisRateHelpers,
    (oisRateHelpers) => oisRateHelpers.convention
  )
  oisRateHelpers: OisRateHelpers[];

  @OneToMany(
    () => SwapRateHelpers,
    (swapRateHelpers) => swapRateHelpers.convention
  )
  swapRateHelpers: SwapRateHelpers[];

  @OneToMany(
    () => XccyRateHelpers,
    (xccyRateHelpers) => xccyRateHelpers.convention
  )
  xccyRateHelpers: XccyRateHelpers[];
}
