import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { LoandepoQuotes } from "./LoandepoQuotes";

@Index("quote_statuses_pkey", ["id"], { unique: true })
@Index("quote_statuses_quote_status_key", ["quoteStatus"], { unique: true })
@Entity("quote_statuses", { schema: "ingfin" })
export class QuoteStatuses {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", {
    name: "quote_status",
    unique: true,
    length: 50,
  })
  quoteStatus: string;

  @OneToMany(
    () => LoandepoQuotes,
    (loandepoQuotes) => loandepoQuotes.quoteStatus
  )
  loandepoQuotes: LoandepoQuotes[];
}
