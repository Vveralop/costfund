import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { AlmCashflows } from "./AlmCashflows";
import { LoanQuoteCashflows } from "./LoanQuoteCashflows";

@Index("cashflow_types_cashflow_type_key", ["cashflowType"], { unique: true })
@Index("cashflow_types_pkey", ["id"], { unique: true })
@Entity("cashflow_types", { schema: "ingfin" })
export class CashflowTypes {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", {
    name: "cashflow_type",
    unique: true,
    length: 50,
  })
  cashflowType: string;

  @OneToMany(() => AlmCashflows, (almCashflows) => almCashflows.cashflowType)
  almCashflows: AlmCashflows[];

  @OneToMany(
    () => LoanQuoteCashflows,
    (loanQuoteCashflows) => loanQuoteCashflows.cashflowType
  )
  loanQuoteCashflows: LoanQuoteCashflows[];
}
