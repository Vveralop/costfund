import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { LoandepoConfigurations } from "./LoandepoConfigurations";

@Index("segments_pkey", ["id"], { unique: true })
@Index("segments_segment_key", ["segment"], { unique: true })
@Entity("segments", { schema: "ingfin" })
export class Segments {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "segment", unique: true, length: 50 })
  segment: string;

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.segment
  )
  loandepoConfigurations: LoandepoConfigurations[];
}
