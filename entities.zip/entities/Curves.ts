import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { BondRateHelpers } from "./BondRateHelpers";
import { CurveDescriptions } from "./CurveDescriptions";
import { CurveSets } from "./CurveSets";
import { DepositRateHelpers } from "./DepositRateHelpers";
import { DiscountCurveValues } from "./DiscountCurveValues";
import { FxswapRateHelpers } from "./FxswapRateHelpers";
import { OisRateHelpers } from "./OisRateHelpers";
import { SwapRateHelpers } from "./SwapRateHelpers";
import { XccyRateHelpers } from "./XccyRateHelpers";

@Index("curves_pkey", ["id"], { unique: true })
@Entity("curves", { schema: "ingfin" })
export class Curves {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("date", { name: "reference_date" })
  referenceDate: string;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @OneToMany(() => BondRateHelpers, (bondRateHelpers) => bondRateHelpers.curve)
  bondRateHelpers: BondRateHelpers[];

  @ManyToOne(
    () => CurveDescriptions,
    (curveDescriptions) => curveDescriptions.curves
  )
  @JoinColumn([{ name: "curve_description_id", referencedColumnName: "id" }])
  curveDescription: CurveDescriptions;

  @ManyToOne(() => CurveSets, (curveSets) => curveSets.curves)
  @JoinColumn([{ name: "curve_set_id", referencedColumnName: "id" }])
  curveSet: CurveSets;

  @OneToMany(
    () => DepositRateHelpers,
    (depositRateHelpers) => depositRateHelpers.curve
  )
  depositRateHelpers: DepositRateHelpers[];

  @OneToMany(
    () => DiscountCurveValues,
    (discountCurveValues) => discountCurveValues.curve
  )
  discountCurveValues: DiscountCurveValues[];

  @OneToMany(
    () => FxswapRateHelpers,
    (fxswapRateHelpers) => fxswapRateHelpers.curve
  )
  fxswapRateHelpers: FxswapRateHelpers[];

  @OneToMany(
    () => FxswapRateHelpers,
    (fxswapRateHelpers) => fxswapRateHelpers.discountCurve
  )
  fxswapRateHelpers2: FxswapRateHelpers[];

  @OneToMany(() => OisRateHelpers, (oisRateHelpers) => oisRateHelpers.curve)
  oisRateHelpers: OisRateHelpers[];

  @OneToMany(
    () => OisRateHelpers,
    (oisRateHelpers) => oisRateHelpers.discountCurve
  )
  oisRateHelpers2: OisRateHelpers[];

  @OneToMany(() => SwapRateHelpers, (swapRateHelpers) => swapRateHelpers.curve)
  swapRateHelpers: SwapRateHelpers[];

  @OneToMany(
    () => SwapRateHelpers,
    (swapRateHelpers) => swapRateHelpers.discountCurve
  )
  swapRateHelpers2: SwapRateHelpers[];

  @OneToMany(() => XccyRateHelpers, (xccyRateHelpers) => xccyRateHelpers.curve)
  xccyRateHelpers: XccyRateHelpers[];

  @OneToMany(
    () => XccyRateHelpers,
    (xccyRateHelpers) => xccyRateHelpers.discountCurve
  )
  xccyRateHelpers2: XccyRateHelpers[];
}
