import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { Curves } from "./Curves";

@Index("discount_curve_values_pkey", ["id"], { unique: true })
@Entity("discount_curve_values", { schema: "ingfin" })
export class DiscountCurveValues {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("date", { name: "date" })
  date: string;

  @Column("double precision", { name: "value", precision: 53 })
  value: number;

  @Column("date", { name: "reference_date" })
  referenceDate: string;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @ManyToOne(() => Curves, (curves) => curves.discountCurveValues)
  @JoinColumn([{ name: "curve_id", referencedColumnName: "id" }])
  curve: Curves;
}
