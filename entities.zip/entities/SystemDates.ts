import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Index("system_dates_pkey", ["id"], { unique: true })
@Index("system_dates_system_date_key", ["systemDate"], { unique: true })
@Entity("system_dates", { schema: "ingfin" })
export class SystemDates {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("date", { name: "system_date", unique: true })
  systemDate: string;
}
