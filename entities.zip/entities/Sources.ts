import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Index("sources_pkey", ["id"], { unique: true })
@Index("sources_source_key", ["source"], { unique: true })
@Entity("sources", { schema: "ingfin" })
export class Sources {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "source", unique: true, length: 50 })
  source: string;
}
