import {
  Column,
  Entity,
  Index,
  JoinColumn,
  ManyToOne,
  PrimaryGeneratedColumn,
} from "typeorm";
import { Calendars } from "./Calendars";
import { Conventions } from "./Conventions";
import { DayCounters } from "./DayCounters";
import { Curves } from "./Curves";
import { Frequencies } from "./Frequencies";

@Index("bond_rate_helpers_pkey", ["id"], { unique: true })
@Entity("bond_rate_helpers", { schema: "ingfin" })
export class BondRateHelpers {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "tenor", length: 50 })
  tenor: string;

  @Column("double precision", { name: "coupon_rate", precision: 53 })
  couponRate: number;

  @Column("integer", { name: "settlement_days" })
  settlementDays: number;

  @Column("boolean", { name: "end_of_month" })
  endOfMonth: boolean;

  @Column("timestamp without time zone", { name: "updated_at" })
  updatedAt: Date;

  @Column("character varying", {
    name: "updated_by",
    nullable: true,
    length: 50,
  })
  updatedBy: string | null;

  @Column("double precision", {
    name: "rate_value",
    nullable: true,
    precision: 53,
  })
  rateValue: number | null;

  @Column("character varying", {
    name: "rate_ticker",
    nullable: true,
    length: 100,
  })
  rateTicker: string | null;

  @ManyToOne(() => Calendars, (calendars) => calendars.bondRateHelpers)
  @JoinColumn([{ name: "calendar_id", referencedColumnName: "id" }])
  calendar: Calendars;

  @ManyToOne(() => Conventions, (conventions) => conventions.bondRateHelpers)
  @JoinColumn([{ name: "convention_id", referencedColumnName: "id" }])
  convention: Conventions;

  @ManyToOne(() => DayCounters, (dayCounters) => dayCounters.bondRateHelpers)
  @JoinColumn([{ name: "coupon_day_counter_id", referencedColumnName: "id" }])
  couponDayCounter: DayCounters;

  @ManyToOne(() => Curves, (curves) => curves.bondRateHelpers)
  @JoinColumn([{ name: "curve_id", referencedColumnName: "id" }])
  curve: Curves;

  @ManyToOne(() => Frequencies, (frequencies) => frequencies.bondRateHelpers)
  @JoinColumn([{ name: "frequency_id", referencedColumnName: "id" }])
  frequency: Frequencies;
}
