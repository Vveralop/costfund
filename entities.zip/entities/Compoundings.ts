import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { LoandepoConfigurations } from "./LoandepoConfigurations";

@Index("compoundings_compounding_key", ["compounding"], { unique: true })
@Index("compoundings_pkey", ["id"], { unique: true })
@Entity("compoundings", { schema: "ingfin" })
export class Compoundings {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", {
    name: "compounding",
    unique: true,
    length: 50,
  })
  compounding: string;

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.firstRateCompounding
  )
  loandepoConfigurations: LoandepoConfigurations[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.secondRateCompounding
  )
  loandepoConfigurations2: LoandepoConfigurations[];
}
