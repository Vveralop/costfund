import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { LoandepoConfigurations } from "./LoandepoConfigurations";

@Index("account_types_account_type_key", ["accountType"], { unique: true })
@Index("account_types_pkey", ["id"], { unique: true })
@Entity("account_types", { schema: "ingfin" })
export class AccountTypes {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", {
    name: "account_type",
    unique: true,
    length: 50,
  })
  accountType: string;

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.accountType
  )
  loandepoConfigurations: LoandepoConfigurations[];
}
