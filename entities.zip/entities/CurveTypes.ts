import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { CurveDescriptions } from "./CurveDescriptions";

@Index("curve_types_curve_type_key", ["curveType"], { unique: true })
@Index("curve_types_pkey", ["id"], { unique: true })
@Entity("curve_types", { schema: "ingfin" })
export class CurveTypes {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "curve_type", unique: true, length: 50 })
  curveType: string;

  @OneToMany(
    () => CurveDescriptions,
    (curveDescriptions) => curveDescriptions.curveType
  )
  curveDescriptions: CurveDescriptions[];
}
