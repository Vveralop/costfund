import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { LoandepoConfigurations } from "./LoandepoConfigurations";

@Index(
  "date_generation_rules_date_generation_rule_key",
  ["dateGenerationRule"],
  { unique: true }
)
@Index("date_generation_rules_pkey", ["id"], { unique: true })
@Entity("date_generation_rules", { schema: "ingfin" })
export class DateGenerationRules {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", {
    name: "date_generation_rule",
    unique: true,
    length: 50,
  })
  dateGenerationRule: string;

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.dateGenerationRule
  )
  loandepoConfigurations: LoandepoConfigurations[];
}
