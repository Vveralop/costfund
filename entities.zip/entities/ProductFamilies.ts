import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { LoandepoConfigurations } from "./LoandepoConfigurations";

@Index("product_families_pkey", ["id"], { unique: true })
@Index("product_families_product_family_key", ["productFamily"], {
  unique: true,
})
@Entity("product_families", { schema: "ingfin" })
export class ProductFamilies {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", {
    name: "product_family",
    unique: true,
    length: 50,
  })
  productFamily: string;

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.productFamily
  )
  loandepoConfigurations: LoandepoConfigurations[];
}
