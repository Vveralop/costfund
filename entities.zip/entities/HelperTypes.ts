import { Column, Entity, Index, PrimaryGeneratedColumn } from "typeorm";

@Index("helper_types_helper_type_key", ["helperType"], { unique: true })
@Index("helper_types_pkey", ["id"], { unique: true })
@Entity("helper_types", { schema: "ingfin" })
export class HelperTypes {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", {
    name: "helper_type",
    unique: true,
    length: 50,
  })
  helperType: string;
}
