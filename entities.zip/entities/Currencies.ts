import {
  Column,
  Entity,
  Index,
  OneToMany,
  PrimaryGeneratedColumn,
} from "typeorm";
import { AlmCashflows } from "./AlmCashflows";
import { CurveDescriptions } from "./CurveDescriptions";
import { InterestRateIndexes } from "./InterestRateIndexes";
import { LoanQuoteCashflows } from "./LoanQuoteCashflows";
import { LoandepoConfigurations } from "./LoandepoConfigurations";
import { XccyRateHelpers } from "./XccyRateHelpers";

@Index("currencies_currency_key", ["currency"], { unique: true })
@Index("currencies_pkey", ["id"], { unique: true })
@Entity("currencies", { schema: "ingfin" })
export class Currencies {
  @PrimaryGeneratedColumn({ type: "integer", name: "id" })
  id: number;

  @Column("character varying", { name: "currency", unique: true, length: 50 })
  currency: string;

  @OneToMany(() => AlmCashflows, (almCashflows) => almCashflows.currency)
  almCashflows: AlmCashflows[];

  @OneToMany(
    () => CurveDescriptions,
    (curveDescriptions) => curveDescriptions.currency
  )
  curveDescriptions: CurveDescriptions[];

  @OneToMany(
    () => InterestRateIndexes,
    (interestRateIndexes) => interestRateIndexes.currency
  )
  interestRateIndexes: InterestRateIndexes[];

  @OneToMany(
    () => LoanQuoteCashflows,
    (loanQuoteCashflows) => loanQuoteCashflows.currency
  )
  loanQuoteCashflows: LoanQuoteCashflows[];

  @OneToMany(
    () => LoandepoConfigurations,
    (loandepoConfigurations) => loandepoConfigurations.currency
  )
  loandepoConfigurations: LoandepoConfigurations[];

  @OneToMany(
    () => XccyRateHelpers,
    (xccyRateHelpers) => xccyRateHelpers.fixedLegCurrency
  )
  xccyRateHelpers: XccyRateHelpers[];
}
